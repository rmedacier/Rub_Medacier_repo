package com.revature.exception;

/*
 * This is a runtime (unchecked) exception.
 */
public class UncheckedCoffeeException extends RuntimeException{

}
