
public class NotImportable {

	/*
	 * This class is in Java's default package. It is NOT
	 * good practice to place your classes in this package
	 * as they cannot be imported for use in other packages.
	 */
}
