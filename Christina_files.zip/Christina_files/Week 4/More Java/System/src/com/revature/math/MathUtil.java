package com.revature.math;

public class MathUtil {

	/*
	 * Java's Math class provides this utility already, so there's no need to do it.
	 */
	public int add(int a, int b) {
		return a + b;
	}
	
	public static void main(String...args) {
		int a = 8;
		int b = -2;
		
		System.out.println(Math.abs(b));
		
		System.out.println(Math.addExact(a, b));
	}
}
