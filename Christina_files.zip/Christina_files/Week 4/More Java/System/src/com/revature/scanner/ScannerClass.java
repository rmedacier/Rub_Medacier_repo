package com.revature.scanner;

import java.util.Scanner;

public class ScannerClass {

	public static void main(String...args) {
		
//		try {
//			int input = System.in.read();
//			System.out.println(input);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
			
		System.out.println("Enter your username:");
		Scanner scan = new Scanner(System.in);
		
		/*
		 * Note that the nextLine method takes an entire line (so it takes the newline
		 * character \n at the end of the line).
		 */
		String message = scan.nextLine();
		
		System.out.println("Enter your age:");
		
		/*
		 * nextInt is used to parse data as an int. Please note that you will get an
		 * InputMismatchException if the data can't be parse as an int.
		 */
		int a = scan.nextInt();
		
		System.out.println("Please enter your address:");
		
		/*
		 * Note that nextInt does NOT consume the newline character as it only takes
		 * the next int in the stream of data. This means that after the user hits
		 * the Enter key, there will be a newline character still in the stream. As a 
		 * result, when you call nextLine again, nextLine will take data up until that
		 * newline character, meaning that this next line of code will NOT have the effect
		 * you think it will!
		 */
//		String address = scan.nextLine();
		
		//I must consume the newline character first!
		
		scan.nextLine(); //consume the newline character
		String address = scan.nextLine(); //read from the stream again		
		
		scan.close(); //please remember to close your Scanner!
	}	
}
