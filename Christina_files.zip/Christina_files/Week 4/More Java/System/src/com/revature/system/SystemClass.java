package com.revature.system;

public class SystemClass {

	public static void main(String...args) {
		
		//"out" is a field on the system class
		System.out.println("Using this output stream to print to the console.");
		
		//Getting our current system time!
		System.out.println(System.currentTimeMillis());
		
		//Access my machine's environment variables.
		System.out.println(System.getenv("JAVA_HOME"));
	}
}
