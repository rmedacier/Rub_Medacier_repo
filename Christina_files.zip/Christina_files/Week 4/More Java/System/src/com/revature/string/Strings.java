package com.revature.string;

public class Strings {

	public static void main(String...args) {
		
		int a = 8;
		boolean b = false;
		char[] myName = {'c', 'h', 'r', 'i', 's'};
		
		System.out.println(String.valueOf(a));
		System.out.println(String.valueOf(b));
		
		String myName2 = String.copyValueOf(myName);
		
		//Array actually allows you to print the name nicely...
		System.out.println(myName);
		System.out.println(myName2);
		
		//...but what if you wanted to modify the name? Recall that arrays are fixed
		//in size, so I would have to create another array.
		
		String myFullName = myName2.concat("tina");
		System.out.println(myFullName);
		
		
	}
}
