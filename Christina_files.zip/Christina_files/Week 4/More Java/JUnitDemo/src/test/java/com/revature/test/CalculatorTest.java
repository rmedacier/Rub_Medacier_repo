package com.revature.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.revature.model.Calculator;

public class CalculatorTest {

	/*
	 * This method will be run ONCE before all of the methods in the class.
	 * As a result, it is typically used to provide some setup that must
	 * be shared across all test methods for the entire test class.
	 */
	
	private static Calculator calc;
	
	@BeforeClass
	public static void setup() {
		System.out.println("I execute once. :)");
		//I've created once instance of the Calculator class to be shared
		//across all of my test cases.
		calc = new Calculator();
	}
	
	/*
	 * Any method annotated with @Before will be run one before every single test
	 * method. One common use of this annotation is to reset state if you have
	 * a test object that is used to track state.
	 */
	@Before
	public void beforeEach() {
		System.out.println("I execute once before EVERY SINGLE TEST METHOD.");
	}
	
	/*
	 * When using JUnit, you will define several test methods. These
	 * methods will call a method that you wish to test so that you
	 * can assert that the output is what you're expecting.
	 */
	
	/*
	 * This annotation denotes that this method is a JUnit test!
	 */
	@Test
	public void testAdd() {
		
		/*
		 * In order to compare an actual result to an expected result,
		 * we can use JUnit Assertions (you must import the Assert class
		 * which contains several static methods).
		 */
		
		/*
		 * This method expects c.add(3, 7) to return 10. If the second argument
		 * (which is whatever c.add(3, 7) returns in this case,
		 * does not resolve to "10", I know that there is a flaw in the method logic
		 * for the add method.
		 */
		Assert.assertEquals(10, calc.add(3, 7));
	}
	
	@Test
	@Ignore //This indicates that I do NOT want to run this test!
	public void testSubtract() {
		Assert.assertEquals(10, calc.subtract(13, 3));
	}
	
	@Test
	public void notWrittenYet() {
		/*
		 * If you want a method to fail, you can use the "fail" method!
		 * This is better than leaving the test method's implementation
		 * blank as a blank method body is reported by JUnit as a 
		 * passed test.
		 */
		Assert.fail("Not yet implemented!");
	}
	
	/*
	 * The After annotation is often used to perform any teardown that would be required
	 * after every single method.
	 */
	@After
	public void afterEach() {
		System.out.println("I execute once after EVERY SINGLE TEST METHOD.");
	}
	
	/*
	 * The AfterClass annotation is typically used to close connections to your DB and
	 * close any streams.
	 */
	@AfterClass
	public static void tearDown() {
		System.out.println("I execute once AFTER all test methods have been executed.");
	}
}
