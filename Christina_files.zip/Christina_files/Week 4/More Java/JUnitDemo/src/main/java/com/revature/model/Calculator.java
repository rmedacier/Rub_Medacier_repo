package com.revature.model;

public class Calculator {

	public int add(int x, int y) {
		return x + y;
	}
	
	/*
	 * This is not an appropriate way to test your code. It works, but
	 * you should note that it doesn't scale particularly well.
	 */
//	public static void main(String...args) {
//		Calculator c = new Calculator();
//		System.out.println(c.add(3, 4));
//	}
	
	public int subtract(int x, int y) {
		return x - y;
	}
}
