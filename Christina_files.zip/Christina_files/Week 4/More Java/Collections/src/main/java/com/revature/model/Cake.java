package com.revature.model;

/*
 * In order to define a natural ordering for Cake, our Cake class needs to implement
 * the Comparable interface and override the compareTo method.
 * 
 * Note that the Comparable interface only allows us to define one way of comparing
 * Cake instances, so it is limited.
 */
public class Cake implements Comparable<Cake>{

	private String flavor;
	private int tastiness; //ranges from 0 to 100
	private int diameter; // [1 to infinity]
	
	public Cake() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cake(String flavor, int tastiness, int diameter) {
		super();
		this.flavor = flavor;
		this.tastiness = tastiness;
		this.diameter = diameter;
	}

	public String getFlavor() {
		return flavor;
	}

	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	public int getTastiness() {
		return tastiness;
	}

	public void setTastiness(int tastiness) {
		this.tastiness = tastiness;
	}

	public int getDiameter() {
		return diameter;
	}

	public void setDiameter(int diameter) {
		this.diameter = diameter;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + diameter;
		result = prime * result + ((flavor == null) ? 0 : flavor.hashCode());
		result = prime * result + tastiness;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cake other = (Cake) obj;
		if (diameter != other.diameter)
			return false;
		if (flavor == null) {
			if (other.flavor != null)
				return false;
		} else if (!flavor.equals(other.flavor))
			return false;
		if (tastiness != other.tastiness)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Cake [flavor=" + flavor + ", tastiness=" + tastiness + ", diameter=" + diameter + "]";
	}

	/*
	 * Note that this method returns an int. If it returns 0, this means that both
	 * instances are considered "equal". If it returns a positive integer, this means
	 * that the cake instance on which it has been called is "greater" than the instance
	 * that has been passed to this method. It it returns a negative integer, this means
	 * that the cakde instance on which it has been called is "less" than the instance
	 * that has been passed to this method.
	 * 
	 * In this case, I will choose to use "tastiness" to compare my cakes. Note that
	 * I could have chosen to compare cakes in any way I wanted to.
	 */
	@Override
	public int compareTo(Cake o) {
		if(this.tastiness < o.tastiness) {
			return -1;
		}
		
		if(this.tastiness > o.tastiness) {
			return 1;
		}
		
		return 0;
	}
	
}
