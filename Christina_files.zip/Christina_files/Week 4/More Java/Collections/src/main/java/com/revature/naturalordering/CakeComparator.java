package com.revature.naturalordering;

import java.util.Comparator;

import com.revature.model.Cake;

/*
 * The first thing to note about the Comparator interface is that it is external
 * to your Cake class. This means that you will need to pass instances of the Cake class
 * to a comparator!
 */
public class CakeComparator implements Comparator<Cake>{

	/*
	 * This allows me to define yet another way of sorting my cakes! If I want to use,
	 * for instance, the size of a cake instead, I can define that logic here!
	 */
	@Override
	public int compare(Cake o1, Cake o2) {
		if(o1.getDiameter() < o2.getDiameter()) {
			return -1;
		}
		
		if(o1.getDiameter() > o2.getDiameter()) {
			return 1;
		}
		
		return 0;
	}

}
