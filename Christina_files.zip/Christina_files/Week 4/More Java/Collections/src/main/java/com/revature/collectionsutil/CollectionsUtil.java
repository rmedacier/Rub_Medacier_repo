package com.revature.collectionsutil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.revature.model.Cake;
import com.revature.naturalordering.CakeComparator;

public class CollectionsUtil {

	public static void main(String...args) {
		
		List<String> strings = new ArrayList<>();
		List<Integer> ints = new ArrayList<>();
		
		//Add a few strings to strings list
		strings.add("My");
		strings.add("name");
		strings.add("is");
		strings.add("Christina.");
		
		//Add a few integers to the ints list
		ints.add(1);
		ints.add(0);
		ints.add(98);
		ints.add(43);
		
		//Let's take a look at the addAll. Note that the method takes
		//variable arguments.
		
		Collections.addAll(strings, " And", " I", " am", " adding", "many", " strings.");
		
		for(String s : strings) {
			System.out.println(s);
		}
		
		//Let's the find the maximum number in ints!
		
		//There is no need to manually do this when we have the max method!
//		Integer holder = ints.get(0);
//		
//		for(Integer i : ints) {
//			if(i > holder) {
//				holder = i;
//			}
//		}
		
		System.out.println(Collections.max(ints));
		
		//You can also easily find the minimum element!
		
		System.out.println(Collections.min(ints));
		
		//It also works with Strings!
		System.out.println(Collections.min(strings));
		
		/*
		 * If we use shuffle, we can randomize all of the elements in our collection.
		 */
		
		Collections.shuffle(strings);
		
		System.out.println(strings);
		
		/*
		 * If we use sort, we can order our numbers in our ints list from smallest number
		 * to largest number.
		 */
		
		Collections.sort(ints);
		
		System.out.println(ints);
		
		/*
		 * We can also swap two elements in a collection!
		 */
		
		Collections.swap(ints, 0, 3);
		
		System.out.println(ints);
		
		/*
		 * Let's create a collection of Cakes!
		 */
		
		List<Cake> cakes = new ArrayList<>();
		
		Cake c1 = new Cake("chocolate", 60, 10);
		Cake c2 = new Cake("vanilla", 75, 12);
		Cake c3 = new Cake("carrot", 70, 8);
		
		//Don't forget to actually add the cakes to the list!
		
		Collections.addAll(cakes, c1, c2, c3);
		
		//When you want to sort a custom type, you need to tell Java how
		//it should be sorted.
		
		/*
		 * There are two ways of handling this in Java:
		 * 
		 * 1) You can use the Comparable interface!
		 * 2) You can use the Comparator interface!
		 */
		Collections.sort(cakes);
		
		System.out.println(cakes);
		
		//Let's create a new instance of the cake comparator that we can pass to the
		//sort method to specify another way of sorting!
		CakeComparator cc = new CakeComparator();
		
		Collections.sort(cakes, cc);
		
		System.out.println(cakes);
		
	}
}
