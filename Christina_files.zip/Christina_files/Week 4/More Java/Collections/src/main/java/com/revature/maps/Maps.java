package com.revature.maps;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
 * The Map interface is NOT a subinterface of the Collection interface. It is also not
 * iterable (meaning that you can't iterate over it using a for-each loop).
 * 
 * That said, you can still store groups of objects inside of a Map. You just have to
 * access all of those objects using a special key (which you specify).
 */
public class Maps {

	public static void main(String...args) {
		
		/*
		 * You can also use generics with Map implementations! Note that the generics
		 * for a Map require that you specify the key type and the value type. In this
		 * case, this map accepts an integer as a key and a string as an underlying
		 * value that can be accessed using that key.
		 */
		Map<Integer, String> imTheMap = new HashMap<>();
		
		//How do I add elements to a Map? Using the "put" method!
		
		imTheMap.put(1, "I'm the first string!");
		imTheMap.put(2, "second string value!");
		imTheMap.put(3, "threeee!");
		imTheMap.put(4, "4");
		
		/*
		 * Note that maps can't have duplicate keys as this doesn't make sense. We need
		 * a unique way to access all values. If you were to specify the same key twice,
		 * you would just overwrite the existing value of the key.
		 */
		imTheMap.put(1, "one again!");
		
		System.out.println(imTheMap);
		
		/*
		 * You can remove objects from maps, but you need to know the key!
		 */
		
		imTheMap.remove(1);
		
		System.out.println(imTheMap);
		
		/*
		 * Recall that maps are NOT iterable. This means that I can't iterate over them 
		 * using an iterator or a for-each loop.
		 * 
		 * If you want to "iterate" over a map in Java, you must get the keys as a set
		 * and iterate over that set!
		 */
		
		Set<Integer> mapKeys = imTheMap.keySet();
		
		for(Integer i : mapKeys) {
			if(i == 3) {
				System.out.println(imTheMap.get(i));
			}
		}
	}
}
