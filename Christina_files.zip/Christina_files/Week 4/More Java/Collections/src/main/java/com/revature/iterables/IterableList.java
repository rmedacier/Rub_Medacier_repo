package com.revature.iterables;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * Collection inherits from the Iterable interface. This means that the
 * subinterfaces of Collection (List, Set, and Queue) also inherit from
 * Iterable. This means that they are iterable, so we can target them with
 * for-each loops and/or use an iterator.
 */
public class IterableList {

	public static void main(String...args) {
		
		/*
		 * As a reminder, this <> syntax is used with generics. Generics
		 * allow us to enforce a type on a collection. This means that I
		 * can only add objects of type String to this collection in this
		 * case.
		 */
		List<String> myStrings = new ArrayList<>();
		
		//Add some strings to our list of strings!
		myStrings.add("string 1");
		myStrings.add("string 2");
		myStrings.add("string 3");
		myStrings.add("This sounds like a Dr. Seuss book.");
		
		//The List interface is Iterable, so I can target its implementations
		//with a for-each loop.
		
		for(String s : myStrings) {
			System.out.println(s);
		}
		
		/*
		 * You can alternatively use an iterator to iterate over a collection
		 * that is iterable. In fact, iterable collections inherit a method
		 * called iterator().
		 */
		
		Iterator<String> it = myStrings.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
