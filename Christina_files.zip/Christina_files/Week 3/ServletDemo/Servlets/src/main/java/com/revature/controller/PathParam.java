package com.revature.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.service.SuperPowerService;

/**
 * Servlet implementation class PathParam
 */
public class PathParam extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private SuperPowerService superPowerService;   
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PathParam() {
        this.superPowerService = new SuperPowerService();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * Instead of using query parameters, let's attempt to use a path parameter.
		 * We are going to have to parse the URI sent to us from the client!
		 */
		
		String uri = request.getRequestURI();
		
		String []uriPieces = uri.split("/");
		
		/*
		 * We need to convert our path parameter into an int as our
		 * findSuperPowerById method takes an int! Note that a NumberFormatException
		 * might be thrown if the path parameter is NOT parsible as a number.
		 * That said, it would be a good idea to perform some sort of exception
		 * handling here.
		 */
		
		Integer id = Integer.parseInt(uriPieces[4]);
		
		/*
		 * Note that the reference type of id is actually Integer, which is
		 * an object. Our findSuperPowerById method takes a primitive (int), but
		 * we can still pass our id to this method. Why? Because Java automatically
		 * unboxes primitives. This unboxing is an automatic conversion of a
		 * wrapper class object into a primitive.
		 * 
		 * Let's go ahead and just add the JSON representation of this object
		 * to the response body!
		 */
		response.getWriter()
		.write(new ObjectMapper()
				.writeValueAsString(this.superPowerService
						.findSuperPowerById(id)));
		
		
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
