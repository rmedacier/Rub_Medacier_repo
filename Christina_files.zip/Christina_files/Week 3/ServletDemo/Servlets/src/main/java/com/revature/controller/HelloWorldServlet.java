package com.revature.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * Note that a servlet is a just a Java class that extends HttpServlet!
 */
public class HelloWorldServlet extends HttpServlet{

	/*
	 * Our servlet class is mapped, but it still needs handler methods for
	 * the different HTTP verbs. For instance, if the client makes a GET
	 * request, we need a method that can handle that GET request. This is
	 * the traditional signature for the handler method for GET requests:
	 */
	
	/*
	 * The HttpServletRequest is an object representation of the Http Request that the client sent
	 * back to the server. The HttpServletResponse is an object representation of the response
	 * that the server will send back to the client.
	 */
	
	/*
	 * Note that we have two handler methods in this class. One of them handles GET requests
	 * while the other handles POST requests. There are some slight differences between
	 * how these two HTTP verbs work.
	 * 
	 * The GET Http verb is less secure than the POST verb. If you use a GET
	 * request to send data from the client to the server, that data will be
	 * appended to the URL.
	 * 
	 * If you use a POST request to send data from the client to the server, that
	 * data will be appended to the request body.
	 * 
	 * The GET verb does not support the transmission of as much data as the POST verb. You have
	 * an upper limit on how much data you can send.
	 * 
	 * POST, on the other hand, allows you to send a NEAR limitless amount of data.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		response.getWriter().write("Hello from the server side!");
	}
	
	/*
	 * Let's define a handler method for HTTP POST requests!
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		/*
		 * How do you access information that is sent from the client side to the server?
		 * 
		 * Using our request reference, we can get access to the request head and body. This
		 * means that we can view the request URL, the data that the client passed back, etc...
		 */
		
		//This allows us to get the query string!
//		response.getWriter().write(request.getQueryString());
		
		//Note that these parameter names are defined by the client. The server
		//must refer to those parameters by their exact names in order to access
		//the value of the parameter.
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		
		response.getWriter().write("Your username is: " + username 
				+ " and your password is: " + password + ".");
		
	}
	
	
}
