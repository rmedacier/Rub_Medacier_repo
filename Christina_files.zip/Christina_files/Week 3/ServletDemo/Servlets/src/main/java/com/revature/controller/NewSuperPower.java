package com.revature.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.model.SuperPower;
import com.revature.service.SuperPowerService;

/**
 * Servlet implementation class NewSuperPower
 */
public class NewSuperPower extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private SuperPowerService superPowerService;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewSuperPower() {
        super();
        this.superPowerService = new SuperPowerService();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*
		 * Get the client's input by finding the value of the  parameter the client sent back.
		 */
		final String newPower = request.getParameter("newpower");
		
		/*
		 * Create a new SuperPower instance, passing the client's input in as the
		 * name of that new super power.
		 */
		SuperPower superPower = new SuperPower(1, newPower);
		
		/*
		 * Use our service object to pass the newly created super power object
		 * to the data layer, where it will be inserted into the database.
		 */
		this.superPowerService.insertPowerSuper(superPower);
		
		/*
		 * If you want to, you can send back a message to the client letting the
		 * client know that the insert into the DB was successful.
		 */
		
		response.getWriter().write("Super Power inserted successfully!");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
