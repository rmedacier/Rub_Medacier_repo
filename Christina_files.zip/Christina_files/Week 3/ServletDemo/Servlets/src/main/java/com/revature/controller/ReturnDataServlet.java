package com.revature.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.service.SuperPowerService;

/**
 * Servlet implementation class ReturnDataServlet
 */
public class ReturnDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SuperPowerService superPowerService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReturnDataServlet() {
        super();
        this.superPowerService = new SuperPowerService();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * Retrieving a parameter that the client sent to the server. That parameter
		 * will be called "power".
		 */
		final String power = request.getParameter("power");
		
		/*
		 * You can send back many types of data to the client. We've already sent plain text
		 * back to the client from the server a couple of times, but we can also send:
		 */
		
		//HTML
		//NOTE: If we're being as precise and careful as possible, we should tell
		//the client the type of content we're intending to send back!
//		response.setContentType("text/html");
//		response.getWriter().write("<h1>Hello from the server side!</h1> <p>This is kind of painful!</p>");
		
		/*
		 * It's perfectly valid to send write anything you want in any format to
		 * the response body! That said, it's not standard to do so. There are standard
		 * formats for data interchange between applications for a reason. It establishes
		 * some common ground for data interchange.
		 * 
		 * Thus, I'm commenting out this code as we will not simply send data to the
		 * client using the toString method...
		 */
//		response.setContentType("text/plain");
//		response.getWriter().write(this.superPowerService
//				.appendToSuperPowerName("my string")
//				.toString());
		
		/*
		 * Let's instead use a standard format for sending data to the client: JSON.
		 * In order to send JSON, we can either:
		 * 
		 * 1) Manually format the string we write to the response body as JSON. That
		 *    said, this is unnecessary if you already have a tool that does the
		 *    formatting for you!
		 * 2) Use a tool that takes care of formatting for you (hint: Jackson's
		 *    ObjectMapper). NOTE: Jackson is not the only option for serialization.
		 *    There are other tools, one such tool being the GSON library.
		 */
		ObjectMapper imTheMap = new ObjectMapper();
		
		/*
		 * Note that the only thing that the ObjectMapper does in this line of code
		 * is convert your Java object into a JSON string representation of itself.
		 * It doesn't actually write to the response body!
		 */
		final String JSON = imTheMap.writeValueAsString(this.superPowerService
				.findSuperPowerByName(power));
		
		//Write your JSON to the response body!
//		response.getWriter().write(JSON);
		
		/*
		 * As a general note, when you call the "getWriter" method, a PrintWriter
		 * is returned. You can create a reference variable for your PrintWriter!
		 * Note that the PrintWriter that this method returns will stream data to
		 * the response file that was sent from the client side!
		 */
		//These lines of code also write JSON to the response body!
		PrintWriter imTheWriter = response.getWriter();
		imTheWriter.write(JSON);
		
		//I prefer to use method chaining, which is a syntax you should familiarize
		//yourself with as it is quite common. When you use method chaining, you
		//do not have to create a reference that points to the return value; you
		//can immediately invoke a method on the value that was returned or pass
		//the value to a method.
		
//		response.getWriter()
//		.write(imTheMap.writeValueAsString(this.superPowerService.
//				appendToSuperPowerName("string appended")));
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//When you generate a servlet using your IDE, the default implementation of
		//the doPost method simply calls the doGet method. This means that you
		//only need to implement doGet.
		doGet(request, response);
	}

}
