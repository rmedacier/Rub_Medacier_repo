package com.revature.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/*
 * This is a convenience class that allows us to forgo putting in our
 * credentials on a per method basis in our repository. Ideally, we
 * would only have to write the code that handles our credentials once.
 */

public class ConnectionFactory {

	private static Connection conn; // default values for objects are null

	public static Connection getConnection() {

		//I only want a new connection if I don't already have one!
			try {
				/*
				 * NEVER hardcode your credentials into the application!
				 */
				/*
				 * When no suitable driver can be found, you might have to tell
				 * Java to load the driver class.
				 */
				Class.forName("org.postgresql.Driver");
				conn = DriverManager.getConnection(
						System.getenv("dbconnectionstring"), 
						System.getenv("dbusername"),
						System.getenv("dbpassword")
						);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch(ClassNotFoundException e) {
				e.printStackTrace();
			}
		return conn;
	}
	
	public static Connection getConnectionViaProperties() {
		
		if(conn == null) {
			InputStream iStream = null;
			Properties props = new Properties();
			
			try {
				iStream = ConnectionFactory.class.getResourceAsStream("/application.properties");
				props.load(iStream);
				conn = DriverManager.getConnection(
						props.getProperty("dbconnectionstring"), 
						props.getProperty("dbusername"), 
						props.getProperty("dbpassword")
						);
			}catch(IOException e) {
				e.printStackTrace();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		return conn;
	}
}
