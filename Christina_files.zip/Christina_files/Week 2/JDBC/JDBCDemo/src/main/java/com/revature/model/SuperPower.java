package com.revature.model;

public class SuperPower {

	private int id;
	private String powerName;
	
	public SuperPower() {
		super();
	}

	public SuperPower(int id, String powerName) {
		super();
		this.id = id;
		this.powerName = powerName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPowerName() {
		return powerName;
	}

	public void setPowerName(String powerName) {
		this.powerName = powerName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((powerName == null) ? 0 : powerName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SuperPower other = (SuperPower) obj;
		if (id != other.id)
			return false;
		if (powerName == null) {
			if (other.powerName != null)
				return false;
		} else if (!powerName.equals(other.powerName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SuperPower [id=" + id + ", powerName=" + powerName + "]";
	}
	
}
