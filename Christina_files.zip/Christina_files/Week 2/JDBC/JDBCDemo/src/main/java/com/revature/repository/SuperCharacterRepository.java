package com.revature.repository;

import java.util.List;

import com.revature.model.SuperCharacter;

public interface SuperCharacterRepository {

	List<SuperCharacter> findAllSuperCharacters();
	SuperCharacter findSuperCharacterById(int id);
	void insertSuperCharacter(SuperCharacter superCharacter);
	void updateSuperCharacter(SuperCharacter superCharacter);
	void deleteSuperCharacter(SuperCharacter superCharacter);
}
