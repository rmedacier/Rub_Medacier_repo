package com.revature;

import com.revature.model.SuperPower;
import com.revature.repository.SuperPowerRepository;
import com.revature.repository.SuperPowerRepositoryImpl;

public class Driver {

	public static void main(String...args) {
		
		SuperPowerRepository superPowerRepository = new SuperPowerRepositoryImpl();
		SuperPower superPower = new SuperPower();
		superPower.setId(6);
		superPower.setPowerName("fire bending");
		
//		superPowerRepository.insertSuperPower(superPower);
//		superPowerRepository.updateSuperPower(superPower);
		System.out.println(superPowerRepository.findAllSuperPowers());
		System.out.println(superPowerRepository.findSuperPowerByName("flight'); drop table super_power;"));
	}
}
