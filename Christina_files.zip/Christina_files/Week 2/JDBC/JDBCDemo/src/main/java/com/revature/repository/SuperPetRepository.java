package com.revature.repository;

import java.util.List;

import com.revature.model.SuperPet;

public interface SuperPetRepository {

	List<SuperPet> findAllSuperPets();
	SuperPet findSuperPetById(int id);
	void insertSuperPet(SuperPet superPet);
	void updateSuperPet(SuperPet superPet);
	void deleteSuperPet(SuperPet superPet);
}
