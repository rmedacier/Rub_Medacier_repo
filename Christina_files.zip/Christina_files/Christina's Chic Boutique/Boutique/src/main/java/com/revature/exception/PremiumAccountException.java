package com.revature.exception;

public class PremiumAccountException extends Exception {
	public PremiumAccountException(String message) {
		super(message);
	}
	
}
