package com.revature.model;

import com.revature.exception.PremiumAccountException;

public class PremiumAccount {
	private String acctStatus = "";
	private PremiumCustomer customer;
	private int purchaseNum = 0;
	private long acctNum = 0;
	private boolean premium = false;

	public static void main(String []args) {
		PremiumCustomer sally = new PremiumCustomer("Sally", "123 Sally's Street", "(432)123-4567", 20, 9.4f);
        PremiumAccount sallysAccount = new PremiumAccount("active", sally, 2, 321322);
        
        // Testing out toString method
        System.out.println(sallysAccount.toString() + "\n");
		
		PremiumCustomer bob = new PremiumCustomer("Bob", "123 Bob's Street", "(643)123-4567", 60, 13.4f);
        PremiumAccount bobsAccount = new PremiumAccount("active", bob, 0, 555322);
        
        System.out.println(bobsAccount.toString() + "\n");
        
        // Testing our exception for when purchase number is less than 0
        bobsAccount.setPurchaseNum(-1);
	}
	
	public PremiumAccount() {
		super();
	}
	
	public PremiumAccount (String acctStatus, PremiumCustomer customer, int purchaseNum, long acctNum){
		this.acctStatus = acctStatus;
		this.customer = customer;
		this.acctNum = acctNum;
		setPurchaseNum(purchaseNum);
		premium = (customer.getAge() > 59) ? true : false;
	}
	
	public String getAcctStatus() {
		return acctStatus;
	}

	public void setAcctStatus(String acctStatus) {
		this.acctStatus = acctStatus;
	}

	public PremiumCustomer getCustomer() {
		return customer;
	}
	
	public void setCustomer(PremiumCustomer customer) {
		this.customer = customer;
	}

	public int getPurchaseNum() {
		return purchaseNum;
	}

	public void setPurchaseNum(int purchaseNum) {
		if (purchaseNum < 0) {
			try {
				throw new PremiumAccountException("Purchase number cannot be less than 0");
			} catch (PremiumAccountException e) {
				e.printStackTrace();
			}
		} else {
			this.purchaseNum = purchaseNum;			
		}
	}

	public long getAcctNum() {
		return acctNum;
	}
	
	public boolean isPremium() {
		return premium;
	}

	public void setPremium(boolean premium) {
		this.premium = premium;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (acctNum ^ (acctNum >>> 32));
		result = prime * result + ((acctStatus == null) ? 0 : acctStatus.hashCode());
		result = prime * result + (premium ? 1231 : 1237);
		result = prime * result + purchaseNum;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PremiumAccount other = (PremiumAccount) obj;
		if (acctNum != other.acctNum)
			return false;
		if (acctStatus == null) {
			if (other.acctStatus != null)
				return false;
		} else if (!acctStatus.equals(other.acctStatus))
			return false;
		if (customer != other.customer)
			return false;
		if (premium != other.premium)
			return false;
		if (purchaseNum != other.purchaseNum)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PremiumAccount [acctStatus = " + acctStatus +  ", customer = " + customer
				+ ", purchaseNum = " + purchaseNum + ", acctNum = " + acctNum + ", premium = " + premium + "]";
	}
}