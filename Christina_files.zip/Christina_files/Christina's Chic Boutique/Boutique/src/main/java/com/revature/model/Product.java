package com.revature.model;

public abstract class Product implements MachineWashable{
	protected float Cost;
	protected int Availability;
	protected String PrintPattern;
	protected String Brand;
	protected String Material;
	protected int Size;
	
	// getters and setters
	public float getCost() {
		return Cost;
	}

	public void setCost(float cost) {
		Cost = cost;
	}

	public int getAvailability() {
		return Availability;
	}

	public void setAvailability(int availability) {
		Availability = availability;
	}

	public String getPrintPattern() {
		return PrintPattern;
	}

	public void setPrintPattern(String printPattern) {
		PrintPattern = printPattern;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public String getMaterial() {
		return Material;
	}

	public void setMaterial(String material) {
		Material = material;
	}

	public int getSize() {
		return Size;
	}

	public void setSize(int size) {
		Size = size;
	}
	
	//Method for modifying the availability and material.
	public abstract float ProductConfig(int Availability, String Material);

}
