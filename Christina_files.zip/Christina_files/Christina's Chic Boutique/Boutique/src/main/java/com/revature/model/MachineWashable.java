package com.revature.model;

public interface MachineWashable {
	
	//purpose of this method is to show if a product is machine washable or not
	public abstract boolean isWashable();
}
