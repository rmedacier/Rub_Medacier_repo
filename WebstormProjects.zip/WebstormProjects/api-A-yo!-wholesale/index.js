const PORT = 8090
const express = require('express')
const axios = require('axios')
const cheerio = require('cheerio')

const app = express()

const shopping_Links = []


app.get('/', (req, res) => {

    res.json('A YYOOOOO! Welcome to my API where we can accommodate all your needs')

})

app.get('/shop-product', (req, res) => {

    axios.get('https://stopandshop.com/groceries/snacks-candy/chips.html').then((response) => {

            const html = response.data
            const $ = cheerio.load(html)
            $('a:contains:("snacks")', html).each(function() {

                const product_Link = $(this).html()
                 const url = $(this).attributes('href')
                shopping_Links.push({
                    product_Link,
                    url



                })

            })
             res.json(shopping_Links)

        }).catch((err) => console.log(err))

})


app.listen(PORT, () => console.log(`server running on ${PORT}`))






